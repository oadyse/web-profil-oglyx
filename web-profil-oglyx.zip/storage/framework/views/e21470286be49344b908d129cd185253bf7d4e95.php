<?php echo $__env->make('layout_landing.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ======= Hero Produk Section ======= -->
<section id="produk">
    <div class="produk-container" data-aos="fade-up">
        <h2>Daftar Produk</h2>
        <h1 class="mb-5">UD. Oglyx Pandiga</h1>
    </div>
</section><!-- End Hero Produk -->

<main id="main">

    <!-- ======= Portfolio Section ======= -->
    <section class="portfolio">
        <div class="container">

            <div class="section-title" data-aos="fade-in" data-aos-delay="100">
                <h2>Daftar Produk</h2>
            </div>
            <div class="row">
                <div class="col-12 text-center mb-5">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-success" onclick="modalPesanan()">
                        Pesan Produk
                    </button>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#form_search">
                        Cek Pesanan
                    </button>
                </div>

                <!-- Modal Create-->
                <div class="modal fade" id="pemesanan" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header text-center bg-success text-light">
                                <h5 class="modal-title" id="exampleModalLabel">Form Pemesanan</h5>
                                <button type="button" class="btn-close text-light" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="form-pesanan" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="mb-3">
                                        <label class="form-label">Nama</label>
                                        <input type="text" name="nama" id="nama" class="form-control"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Nomor (WhatsApp)</label>
                                        <input type="text" name="no_wa" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Alamat</label>
                                        <textarea class="form-control" name="alamat" rows="3" required></textarea>
                                    </div>
                                    <hr>
                                    <div class="text-center mb-3">
                                        <label><b>Tambahkan jumlah produk yang ingin dipesan:</b></label>
                                    </div>
                                    <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row mb-3 mx-auto">
                                            <div class="col-8 my-auto">
                                                <label class="form-label">
                                                    <small>
                                                        <?php echo e($produk->nama); ?> <br>
                                                        <span style="color: brown;">
                                                            (<?php echo e('Rp ' . number_format($produk->harga, 0, ',', '.') . '/ton'); ?>)
                                                        </span>
                                                        <small>Stok : <?php echo e($produk->stok); ?></small>
                                                    </small>
                                                    <input type="hidden" name="harga[]" value="<?php echo e($produk->harga); ?>" />
                                                </label>
                                            </div>
                                            <div class="col-3 text-center">
                                                <input type="hidden" name="id_produk[]" value="<?php echo e($produk->id); ?>" />
                                                <input type="number" id="total" min="0"
                                                    max="<?php echo e($produk->stok); ?>" name="total[]" class="form-control"
                                                    placeholder="0">
                                            </div>
                                            <div class="col-1">
                                                <small>ton</small>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Lakukan
                                    Pemesanan</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Modal Search-->
                <div class="modal fade" id="form_search" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header text-center bg-warning text-light">
                                <h5 class="modal-title" id="exampleModalLabel">Masukkan Nomor pesanan</h5>
                                <button type="button" class="btn-close text-light" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <!-- Start kode untuk form pencarian -->
                                <form class="form" action="<?php echo e(route('search')); ?>" method="get">
                                    <div class="form-group">
                                        <input type="text" name="search" class="form-control" id="search"
                                            placeholder="Masukkan no-order" value="<?php echo e(old('search')); ?>" required>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Cari</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" data-aos="fade-in">
                <div class="col-lg-12 d-flex justify-content-center">
                    <ul id="portfolio-flters">
                        <li data-filter="*" class="filter-active">All</li>
                        <li data-filter=".filter-app">Bawang Siap Konsumsi</li>
                        <li data-filter=".filter-card">Benih Bawang</li>
                    </ul>
                </div>
            </div>

            <div class="row portfolio-container" data-aos="fade-up">
                <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(strpos($produk->nama, 'Benih') !== false): ?>
                        <div class="col-lg-4 col-md-6 portfolio-item filter-card">
                            <div class="portfolio-wrap" style="height: 200px">
                                <img src="dokumen/produk/<?php echo e($produk->gambar); ?>" class="img-fluid"
                                    alt="<?php echo e($produk->nama); ?>">
                                <div class="portfolio-links">
                                    <a href="dokumen/produk/<?php echo e($produk->gambar); ?>" data-gallery="portfolioGallery"
                                        class="portfolio-lightbox" title="<?php echo e($produk->nama); ?>">
                                        <i class="bx bx-plus"></i>
                                    </a>
                                    <a href="<?php echo e(url('produkdetail/' . $produk->id)); ?>" title="More Details"><i
                                            class="bx bx-link"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                            <div class="portfolio-wrap" style="height: 200px">
                                <img src="dokumen/produk/<?php echo e($produk->gambar); ?>" class="img-fluid"
                                    alt="<?php echo e($produk->nama); ?>">
                                <div class="portfolio-links">
                                    <a href="dokumen/produk/<?php echo e($produk->gambar); ?>" data-gallery="portfolioGallery"
                                        class="portfolio-lightbox" title="<?php echo e($produk->nama); ?>">
                                        <i class="bx bx-plus"></i>
                                    </a>
                                    <a href="<?php echo e(url('produkdetail/' . $produk->id)); ?>" title="More Details"><i
                                            class="bx bx-link"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section><!-- End Portfolio Section -->

</main><!-- End #main -->

<?php echo $__env->make('layout_landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>

<?php echo $__env->make('layout_landing.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/produk.blade.php ENDPATH**/ ?>