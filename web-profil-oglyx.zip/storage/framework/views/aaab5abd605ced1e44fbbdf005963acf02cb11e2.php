<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>UD. Oglyx Pandiga</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('dashboard')); ?>/assets/images/Logo.png" />

    <link rel="stylesheet" href="<?php echo e(asset('dashboard')); ?>/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard')); ?>/assets/css/backend.css?v=1.0.0">
</head>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/layout_dashboard/header.blade.php ENDPATH**/ ?>