<nav id="navbar" class="navbar">
    <ul>
        <li><a class="nav-link scrollto" href="<?php echo e(url('/')); ?>">Beranda</a>
        </li>
        <li><a class="nav-link scrollto" href="#about">Tentang</a></li>
        <li><a class="nav-link scrollto" href="#kerjasama">Kerjasama</a></li>
        <li><a class="nav-link scrollto" href="#capaian">Capaian Prestasi</a></li>
        <li><a class="nav-link scrollto <?php echo e(Request::is('produk') ? 'active' : ''); ?>"
                href="<?php echo e(route('daftar-produk')); ?>">Daftar Produk</a></li>
        <?php if(empty(Auth::user()->name)): ?>
            <li><a class="nav-link scrollto bg-dark" href="<?php echo e(url('login')); ?>">Login</a></li>
        <?php else: ?>
            <li><a class="nav-link scrollto bg-dark" href="<?php echo e(route('menu-dashboard')); ?>">Dashboard</a></li>
        <?php endif; ?>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav><!-- .navbar -->
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/layout_landing/nav.blade.php ENDPATH**/ ?>