<?php if(!empty(Auth::user()->name)): ?>
    <?php echo $__env->make('layout_dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body class="  ">
        <?php echo $__env->make('layout_dashboard.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-page ml-0" style="width: 100%">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-center">
                                <div class="header-title">
                                    <h4 class="card-title">Tabel Daftar Pemesanan</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="datatable-1" class="table data-table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th width="5%">No.</th>
                                                <th width="15%">Tanggal Pesan</th>
                                                <th>Pemesan</th>
                                                <th>Status</th>
                                                <th width="15%">Order</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($orders as $order){
                                            ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($no); ?>.</td>
                                                <td><?php echo e(date('d-m-Y', strtotime($order->created_at))); ?></td>
                                                <td>
                                                    <ul>
                                                        <li><?php echo e('No-Order       : ' . $order->no_order); ?></li>
                                                        <li><?php echo e('Nama           : ' . $order->nama); ?></li>
                                                        <li><?php echo e('Nomor WhatsApp : ' . $order->no_wa); ?></li>
                                                        <li><?php echo e('Alamat         : ' . $order->alamat); ?></li>
                                                    </ul>
                                                </td>
                                                <td><?php echo e($order->status); ?></td>
                                                <td>
                                                    <a class="btn btn-success" href="/detail/<?php echo e($order->id); ?>">
                                                        Detail Pesanan
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php 
                                            $no += 1;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layout_dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>

    </html>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/menu-pesanan.blade.php ENDPATH**/ ?>