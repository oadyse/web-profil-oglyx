<?php echo $__env->make('layout_dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layout_dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="  ">
    <div class="iq-top-navbar" style="width: 100%">
        <div class="iq-navbar-custom mt-3">
            <nav class="navbar navbar-expand-lg navbar-light p-0">
                <div class="side-menu-bt-sidebar">
                    <h4>
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('dashboard')); ?>/assets/images/Logo.png"
                                alt="" class="img-fluid" width="35px">
                            &nbsp; UD. Oglyx Pandiga</a>
                    </h4>
                </div>
                <div class="d-flex align-items-center">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <a class="btn btn-primary btn-sm" href="<?php echo e(url('/produk')); ?>" title="Back">
                            Back to Homepage </a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <div class="content-page ml-0" style="width: 100%">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <?php if(empty($cek)): ?>
                            <div class="text-center m-5">
                                <span>
                                    <i>Data tidak ditemukan atau nomor pesanan yang diinputkan salah!</i>
                                </span>
                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-header d-flex justify-content-center">
                                    <div class="header-title">
                                        <h4 class="card-title">Cek Pemesanan Anda</h4>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-borderless">
                                            <tbody class="font-weight-bold">
                                                <tr>
                                                    <td class="py-0" width="14%">No-Order</td>
                                                    <td class="py-0" width="1%">:</td>
                                                    <td class="py-0" width="85%"><?php echo e($pesanan->no_order); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="py-0" width="14%">Nama</td>
                                                    <td class="py-0" width="1%">:</td>
                                                    <td class="py-0" width="85%"><?php echo e($pesanan->nama); ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="py-0" width="14%">No. WhatsApp</td>
                                                    <td class="py-0" width="1%">:</td>
                                                    <td class="py-0" width="85%"><?php echo e($pesanan->no_wa); ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="py-0" width="14%">Alamat</td>
                                                    <td class="py-0" width="1%">:</td>
                                                    <td class="py-0" width="85%"><?php echo e($pesanan->alamat); ?>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <table id="datatable-1" class="table data-table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Produk</th>
                                                    <th>Harga</th>
                                                    <th>Jumlah</th>
                                                    <th>Total Harga</th>
                                                    <th colspan="4">Status Pesanan</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <?php $__currentLoopData = $pesanan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="mb-2"><?php echo e($detail->produk->nama); ?>

                                                            </div><br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $pesanan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="mb-2">
                                                                <?php echo e('Rp ' . number_format($detail->produk->harga, 2, ',', '.')); ?>

                                                            </div><br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $pesanan->total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="mb-2">
                                                                <?php echo e($total->total); ?> Ton
                                                            </div><br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $all = 0; ?>
                                                        <?php $__currentLoopData = $pesanan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $pesanan->total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($detail == $total): ?>
                                                                    <?php $a = $d->produk->harga * $t->total; ?>
                                                                    <div class="mb-2">
                                                                        <?php echo e('Rp ' . number_format($a, 2, ',', '.')); ?>

                                                                    </div>
                                                                    <br>
                                                                    <?php
                                                                    $all += $a;
                                                                    ?>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <h5>
                                                            <?php $id = $pesanan->id; ?>
                                                            <?php if($pesanan->status == 'Belum Proses'): ?>
                                                                <span class="mt-2 badge badge-secondary">
                                                                    Belum Proses
                                                                </span>
                                                            <?php elseif($pesanan->status == 'Proses'): ?>
                                                                <span class="mt-2 badge badge-warning">
                                                                    Proses
                                                                </span>
                                                            <?php elseif($pesanan->status == 'Selesai'): ?>
                                                                <span class="mt-2 badge badge-success">
                                                                    Selesai
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php echo $__env->make('edit-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </h5>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="text-right" colspan="3"><b>Total Harga
                                                            Pesanan</b></td>
                                                    <td colspan="2">
                                                        <?php echo e('Rp ' . number_format($all, 2, ',', '.')); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layout_dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/cek_pesanan.blade.php ENDPATH**/ ?>