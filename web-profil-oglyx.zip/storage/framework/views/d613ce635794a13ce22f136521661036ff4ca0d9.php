<?php if(!empty(Auth::user()->name)): ?>
    <?php echo $__env->make('layout_dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body class="  ">
        <div class="iq-top-navbar" style="width: 100%">
            <div class="iq-navbar-custom">
                <nav class="navbar navbar-expand-lg navbar-light p-0">
                    <div class="side-menu-bt-sidebar">
                        <h4>
                            <a href="<?php echo e(url('/')); ?>"><img src="assets/img/Logo.png" alt="" class="img-fluid"
                                    width="35px">
                                &nbsp; UD. Oglyx Pandiga</a>
                        </h4>
                    </div>
                </nav>
            </div>
        </div>
        <div class="content-page ml-0" style="width: 100%">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-center">
                                <div class="header-title">
                                    <h4 class="card-title">Cek Pemesanan</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-borderless">
                                        <tbody class="font-weight-bold">
                                            <tr>
                                                <td class="py-0" width="14%">Nama</td>
                                                <td class="py-0" width="1%">:</td>
                                                <td class="py-0" width="85%"><?php echo e($pesanan->nama); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="py-0" width="14%">No. WhatsApp</td>
                                                <td class="py-0" width="1%">:</td>
                                                <td class="py-0" width="85%"><?php echo e($pesanan->no_wa); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="py-0" width="14%">Alamat</td>
                                                <td class="py-0" width="1%">:</td>
                                                <td class="py-0" width="85%"><?php echo e($pesanan->alamat); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table id="datatable-1" class="table data-table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Produk</th>
                                                <th>Harga</th>
                                                <th>Jumlah</th>
                                                <th>Total Harga</th>
                                                <th colspan="4">Status Pesanan</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <?php $__currentLoopData = $pesanan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="mb-2"><?php echo e($detail->nama); ?></div><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php $__currentLoopData = $pesanan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="mb-2">
                                                            <?php echo e('Rp ' . number_format($detail->harga, 2, ',', '.')); ?>

                                                        </div><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php $__currentLoopData = $pesanan->total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="mb-2">
                                                            <?php echo e($total->total); ?> Ton
                                                        </div><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php $all = 0; ?>
                                                    <?php $__currentLoopData = $pesanan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $pesanan->total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($detail == $total): ?>
                                                                <?php $a = $d->harga * $t->total; ?>
                                                                <div class="mb-2">
                                                                    <?php echo e('Rp ' . number_format($a, 2, ',', '.')); ?></div>
                                                                <br>
                                                                <?php
                                                                $a = $d->harga * $t->total;
                                                                $all += $a;
                                                                ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <h5>
                                                        <?php $id = $pesanan->id; ?>
                                                        <?php if($pesanan->status == 'Belum Proses'): ?>
                                                            <span class="mt-2 badge badge-secondary">
                                                                Belum Proses
                                                            </span>
                                                            <a class="iq-icons-list m-1 text-left" href=""
                                                                title="Edit" data-toggle="modal"
                                                                data-target="#edit<?php echo e($id); ?>">
                                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                    viewBox="0 0 24 24" stroke-width="1.5"
                                                                    stroke="currentColor" class="m-0">
                                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                                        d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
                                                                </svg>
                                                            </a>
                                                        <?php elseif($pesanan->status == 'Proses'): ?>
                                                            <span class="mt-2 badge badge-warning">
                                                                Proses
                                                            </span>
                                                            <a class="iq-icons-list m-1 text-left" href=""
                                                                title="Edit" data-toggle="modal"
                                                                data-target="#edit<?php echo e($id); ?>">
                                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                    viewBox="0 0 24 24" stroke-width="1.5"
                                                                    stroke="currentColor" class="m-0">
                                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                                        d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
                                                                </svg>
                                                            </a>
                                                        <?php elseif($pesanan->status == 'Selesai'): ?>
                                                            <span class="mt-2 badge badge-success">
                                                                Selesai
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php echo $__env->make('edit-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </h5>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-right" colspan="3"><b>Total Harga Pesanan</b></td>
                                                <td colspan="2"><?php echo e('Rp ' . number_format($all, 2, ',', '.')); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layout_dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>

    </html>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views//cek_pesanan.blade.php ENDPATH**/ ?>