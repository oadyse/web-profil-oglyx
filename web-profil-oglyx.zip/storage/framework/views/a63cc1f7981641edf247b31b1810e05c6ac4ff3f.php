<!-- Backend Bundle JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/backend-bundle.min.js"></script>
<!-- Chart Custom JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/customizer.js"></script>

<script src="<?php echo e(asset('dashboard')); ?>/assets/js/sidebar.js"></script>

<!-- Flextree Javascript-->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/flex-tree.min.js"></script>
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/tree.js"></script>

<!-- Table Treeview JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/table-treeview.js"></script>

<!-- SweetAlert JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/sweetalert.js"></script>

<!-- Vectoe Map JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/vector-map-custom.js"></script>

<!-- Chart Custom JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/chart-custom.js"></script>
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/charts/01.js"></script>
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/charts/02.js"></script>

<!-- slider JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/slider.js"></script>

<!-- Emoji picker -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/vendor/emoji-picker-element/index.js" type="module"></script>


<!-- app JavaScript -->
<script src="<?php echo e(asset('dashboard')); ?>/assets/js/app.js"></script>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/layout_dashboard/script.blade.php ENDPATH**/ ?>