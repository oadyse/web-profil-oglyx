<?php if(!empty(Auth::user()->name)): ?>
    <?php echo $__env->make('layout_dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body class="  ">
        <?php echo $__env->make('layout_dashboard.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-page ml-0" style="width: 100%">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="header-title">
                                    <h4 class="card-title text-center">Tabel Daftar Produk</h4>
                                    <button class="btn btn-primary btn-sm float-right">Tambah Produk</button>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="datatable-1" class="table data-table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th width="5%">No.</th>
                                                <th>Nama Produk</th>
                                                <th>Harga(per ton)</th>
                                                <th>Jumlah(per ton)</th>
                                                <th width="15%">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            foreach ($product as $produk){
                                            ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($no); ?>.</td>
                                                <td><?php echo e($produk->nama); ?></td>
                                                <td><?php echo e('Rp ' . number_format($produk->harga, 0, ',', '.')); ?></td>
                                                <td><?php echo e($produk->stok); ?></td>
                                                <td>
                                                    <a class="btn btn-warning btn-sm" href="/edit/<?php echo e($produk->id); ?>">
                                                        Ubah
                                                    </a>
                                                    <a class="btn btn-info btn-sm" href="/detail/<?php echo e($produk->id); ?>">
                                                        Detail
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php 
                                            $no += 1;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layout_dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>

    </html>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/menu-produk.blade.php ENDPATH**/ ?>