<div class="iq-top-navbar" style="width: 100%">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0">
            <div class="side-menu-bt-sidebar">
                <h4>
                    <h4>
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('dashboard')); ?>/assets/images/Logo.png"
                                alt="" class="img-fluid" width="35px">
                            &nbsp; UD. Oglyx Pandiga</a>
                    </h4>
                </h4>
            </div>
            <div class="d-flex align-items-center">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-list align-items-center">
                        <li class="nav-item nav-icon mr-2 dropdown">
                            <a href="<?php echo e(route('menu-dashboard')); ?>"><u>Daftar Pesanan</u></a>
                        </li>
                        <li class="nav-item nav-icon mr-2">
                            <h4><b>|</b></h4>
                        </li>
                        <li class="nav-item nav-icon mr-3 dropdown">
                            <a href="<?php echo e(route('menu-produk')); ?>"><u>Daftar Produk</u></a>
                        </li>
                        <li class="nav-item nav-icon dropdown">
                            <a href="#" class="nav-item nav-icon dropdown-toggle pr-0 search-toggle"
                                id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                <img src="<?php echo e(asset('dashboard')); ?>/assets/images/user/1.jpg"
                                    class="img-fluid avatar-rounded" alt="user">
                                <span class="mb-0 ml-2 user-name"><b> <?php echo e(Auth::user()->name); ?> </b></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">

                                <!-- Authentication Links -->
                                <?php if(auth()->guard()->guest()): ?>
                                    <?php if(Route::has('login')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if(Route::has('register')): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <li class="nav-item dropdown">
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                            class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\web-profil-oglyx\resources\views/layout_dashboard/topnav.blade.php ENDPATH**/ ?>