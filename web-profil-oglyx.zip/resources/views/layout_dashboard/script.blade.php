<!-- Backend Bundle JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/backend-bundle.min.js"></script>
<!-- Chart Custom JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/customizer.js"></script>

<script src="{{ asset('dashboard') }}/assets/js/sidebar.js"></script>

<!-- Flextree Javascript-->
<script src="{{ asset('dashboard') }}/assets/js/flex-tree.min.js"></script>
<script src="{{ asset('dashboard') }}/assets/js/tree.js"></script>

<!-- Table Treeview JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/table-treeview.js"></script>

<!-- SweetAlert JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/sweetalert.js"></script>

<!-- Vectoe Map JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/vector-map-custom.js"></script>

<!-- Chart Custom JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/chart-custom.js"></script>
<script src="{{ asset('dashboard') }}/assets/js/charts/01.js"></script>
<script src="{{ asset('dashboard') }}/assets/js/charts/02.js"></script>

<!-- slider JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/slider.js"></script>

<!-- Emoji picker -->
<script src="{{ asset('dashboard') }}/assets/vendor/emoji-picker-element/index.js" type="module"></script>


<!-- app JavaScript -->
<script src="{{ asset('dashboard') }}/assets/js/app.js"></script>
